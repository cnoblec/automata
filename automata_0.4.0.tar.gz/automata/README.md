# automata
PHYS 349 Cellular Automata Project
